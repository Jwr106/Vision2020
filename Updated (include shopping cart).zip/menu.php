	<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 shadow-sm">
		<img src="images/link_opticians_logo.png" class="my-0 mr-md-auto img-responsive" width="180px">
	  <!-- <h5 class="my-0 mr-md-auto font-weight-normal">Link Opticians</h5> -->
	  <nav class="my-2 my-md-0 mr-md-3">
	    <a class="p-2 text-white" href="index.php">Home</a>
	    <a class="p-2 text-white" href="about.php">About Us</a>
	    <a class="p-2 text-white" href="store.php">Store</a>
	    <a class="p-2 text-white" href="news.php">News</a>
	    <a class="p-2 text-white" href="contact.php">Contact Us</a>
	  </nav>
	  <a class="btn btn-primary" href="register.php">Login/Register</a>
	</div>